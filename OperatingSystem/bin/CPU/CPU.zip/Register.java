package CPU;

public class Register {
	
	private int data;
		
	public int getData() {return data;}
	public void setData(int data) {this.data = data;}

	public Register() {
		
	}
}