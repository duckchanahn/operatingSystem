package CPU;

import Memory.Memory;

public class ControlUnit {
	
	public enum EState {halt, wait, running};
	public enum EInstruction {LDV, LDA, ADV, ADA, STA, JGZ, CMP, Halt, INT, loop};
	private EState eState;
	public EState getState() {return eState;}
	public void setState(EState eState) {this.eState = eState;}
//	private EInstruction eInstruction;
	
	private Register pc, sp, cs, mar, mbr, ir, ac;
	public void setPC(Register pc) {this.pc = pc;}
	public void setSP(Register sp) {this.sp = sp;}
	public void setCS(Register cs) {this.cs = cs;}
	public void setStatus(Status status) {this.status = status;}
	private Status status;
	private ArithmeticLogicUnit arithmeticLogicUnit;
	private Memory memory;
	
	public ControlUnit() {
		this.eState = EState.running;
		this.loopIndex = 0;
		this.count = 0;
	}
	
	public void connect(Register pc, Register mar, Register mbr, Register ir, Register sp, Register cs, Register ac, Status status) {
		this.pc = pc;
		this.mar = mar;
		this.mbr = mbr;
		this.ir = ir;
		this.sp = sp;
		this.cs = cs;
		this.ac = ac;
		this.status = status;
	}
	public void connect(ArithmeticLogicUnit arithmeticLogicUnit) {
		this.arithmeticLogicUnit = arithmeticLogicUnit;
	}
	public void connect(Memory memory) {
	      this.memory = memory;
	}

	public void run() {
		this.eState = EState.running;
			this.fetch();
			this.decode();
			if(this.status.interruptCheck()) {
				this.memory.ihr(this.mbr.getData());
			}
	}
	
	private void fetch() {
		int index = this.pc.getData() + this.cs.getData();
		this.mar.setData(index);
		this.memory.fetch();
		this.ir.setData(this.mbr.getData());
	}

	private void decode() {
		int instruction = this.ir.getData() >>> 16;
//		System.out.println(EInstruction.values()[instruction]);
		switch(EInstruction.values()[instruction]) {
			case LDV:
				LDV();
				break;
			case LDA:
				LDA();
				break;
			case ADV:
				ADV();
				break;
			case ADA:
				ADA();
				break;
			case STA:
				STA();
				break;
			case JGZ:
				JGZ();
				break;
			case CMP:
				CMP();
				break;
			case Halt:
				Halt();
				break;
			case INT:
				INT();
				break;
			case loop:
				loop();
				break;
			default:
				break;
		}
	}

	private void LDA() {
		int address = this.ir.getData() & 0x0000ffff;	
		address = address + this.sp.getData();
		this.mar.setData(address);
		this.memory.fetch();
		this.ac.setData(this.mbr.getData());
		this.pc.setData(this.pc.getData()+1);
	}
	private void LDV() {
		int address = this.ir.getData() & 0x0000ffff;	
		this.ac.setData(address);
		this.pc.setData(this.pc.getData()+1);
	}
	private void STA() {
		int address = this.ir.getData() & 0x0000ffff;	
		address = address + this.sp.getData();
		this.mar.setData(address);
		this.mbr.setData(this.ac.getData());
		this.memory.store();
		this.pc.setData(this.pc.getData()+1);
	}
	private void ADV() {
		int address = this.ir.getData() & 0x0000ffff;	
		this.mbr.setData(address);
		this.arithmeticLogicUnit.add();
		this.pc.setData(this.pc.getData()+1);
	}
	private void ADA() {
		int address = this.ir.getData() & 0x0000ffff;	
		address = address + this.sp.getData();
		this.mar.setData(address);
		this.memory.fetch();
		this.arithmeticLogicUnit.add();
		this.pc.setData(this.pc.getData()+1);
	}
	private void Halt() {
		this.eState = EState.halt;
		this.pc.setData(this.pc.getData()+1);
	}
	private void INT() {
		this.eState = EState.wait;
		this.status.setStatus(1);
		int address = this.ir.getData() & 0x0000ffff;
		this.mbr.setData(address);
		System.out.println(this.ac.getData());
	}
	int count;
	private void JGZ() {
		if(!this.status.zeroCheck() && !this.status.signCheck()) {
//			System.out.println("1");
			pc.setData(loopIndex);
		}
		this.pc.setData(this.pc.getData()+1);
	}
	private void CMP() {
		int address = this.ir.getData() & 0x0000ffff;
		this.mar.setData(address);
		this.memory.fetch();
		this.arithmeticLogicUnit.cmp();
		this.pc.setData(this.pc.getData()+1);
	}
	
	int loopIndex;
	private void loop() {
		loopIndex = this.pc.getData() + this.cs.getData();
		this.pc.setData(this.pc.getData()+1);
	}
}
